char *magic_mem =
#include "magic.inc"
;
