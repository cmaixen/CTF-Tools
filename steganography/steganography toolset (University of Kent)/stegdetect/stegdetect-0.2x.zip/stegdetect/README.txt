xsteg is a gtk+ frontend to stegdetect.

This is a direct compilation of the UNIX sources to a Windows binary.
If you run this code on a UNIX-like operating system, you will
experience better performance and stability.

The windows gtk+ libraries are very experimental.

You can support development at

  http://www.outguess.org/