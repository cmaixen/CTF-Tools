Introduction :
==============

Steghide is a steganography program which embeds a secret message in a cover
file by replacing some of the least significant bits of the cover file with bits
of the secret message. After that, the secret message is imperceptible and can
only be extracted with the correct passphrase.

The current version of steghide is 0.4.5.
Features:
support for bmp, wav and au files
encryption of plain data before embedding (blowfish encryption algorithm)
pseudo-random distribution of hidden bits in stego file
embedding of a crc32 checksum of the plain data

Steganography :
===============

Steganography literally means covered writing. Its goal is to hide the fact
that communication is taking place. This is often achieved by using a (rather
large) cover file and embedding the (rather short) secret message into this
file. The result is a innocuous looking file (the stego file) that contains
the secret message.
If you want to know more about steganography take a look at
http://steghide.sourceforge.net/steganography.html

Compilation and Installation :
==============================

Requirements :
--------------
The following libraries are required to compile and use steghide:

* libmhash
a library that provides hashing algorithms - available at:
http://mhash.sourceforge.net/

* libmcrypt
a library that provides encryption algorithms - available at:
http://mcrypt.hellug.gr/

Linux / Unix :
--------------
1) ./configure 
2) make
3) make install

For more information see the generic installation instructions in the file
INSTALL that came with the distribution. Tarballs and RPM packages are available
from the steghide website at:
http://steghide.sourceforge.net/index.html
 
Windows :
---------
The easiest way is to download the precompiled binary (including Windows
versions of the necessary libraries) from the steghide website at:
http://steghide.sourceforge.net/index.html

If you want to compile the sources yourself you need a C compiler. How you need
to compile the source code depends on the compiler you are using: Please
consult your compiler's documentation.

Steghide can be compiled with gcc in the cygwin environment
(http://www.cygwin.com/) using the three steps mentioned above for the
Linux/Unix compilation.

Quick-Start Examples :
======================

Here are some examples how steghide can be used. If you want more detailed
information please take a look at the manpage (type "man steghide" on
Unix/Linux systems, open the file usage.txt on Windows).

To embed the file secret.txt in the wav file cvr.wav and save the resulting
stego file as stg.wav type:

  $ steghide embed -pf secret.txt -cf cvr.wav -sf stg.wav
  Enter passhrase:
  Re-Enter passphrase:
  wrote stego file to "stg.wav".

To extract this data again type:

  $ steghide extract -sf stg.wav
  Enter passphrase:
  wrote plain file to "secret.txt".

When embedding data, the name of the original plain file is embedded too: The
extract command above will create a file secret.txt in the current directory
and write the embedded data to secret.txt.

You can override the embedded plain file name if you specify a -pf argument
when extracting. The following command will put the embedded data into the file
plain.txt:

  $ steghide extract -sf stg.wav -pf plain.txt
  Enter passphrase:
  wrote plain file to "plain.txt".

If you are using a system that supports pipes you can pass data via
standard input to steghide. In the following example data is compressed before
it is (encrypted and) embedded:

  $ gzip -c pln.txt | steghide embed -cf cvr.bmp -sf stg.bmp -pf - -p "This is a passphrase."
  wrote stego file to "stg.bmp".

To extract (and view) the data from this file again, you could do something
like this:

  $ steghide extract -sf stg.bmp -pf - -p "This is a passphrase." | gunzip | less

If you pass data to steghide via standard input or from steghide to another
program via standard output, you need to specify the passphrase on the command
line with the -p argument (as shown in the two commands above).

Contact :
=========

Website :
---------
You can get the latest version of steghide as well as some additional
information from the steghide website at:
http://steghide.sourceforge.net/index.html

Mailing Lists :
---------------
If you have found a bug or if you have questions, comments, suggestions, etc.
please send a mail to the development mailing list:
steghide-devel@lists.sourceforge.net
To receive mails sent to this list, subscribe to it at:
http://lists.sourceforge.net/lists/listinfo/steghide-devel

If you want to be informed, when a new version of steghide is released please
subscribe to the steghide announcement mailing list at:
http://lists.sourceforge.net/lists/listinfo/steghide-announce

Anonymous CVS access :
----------------------

You can access the most recent development source code via anonymous cvs. Just
type the following lines:

$ cvs -d:pserver:anonymous@cvs.steghide.sourceforge.net:/cvsroot/steghide login
CVS password:  [ Hit RETURN here ]

$ cvs -z3 -d:pserver:anonymous@cvs.steghide.sourceforge.net:/cvsroot/steghide co steghide

You can also browse the cvs repository on the web:
http://cvs.sourceforge.net/cgi-bin/viewcvs.cgi/steghide/

Author :
--------
You can contact me (Stefan Hetzl) via e-mail: shetzl@teleweb.at
