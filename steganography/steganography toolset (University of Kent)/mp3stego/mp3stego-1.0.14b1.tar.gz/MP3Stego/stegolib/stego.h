#ifndef _STEGO_H_
#define _STEGO_H_

#if defined(DEBUG) | defined(_DEBUG)
extern FILE *fLog;
#endif

#define STEGO_VERSION ("1.0.14")

/* Encoding */
void StegoOpenEmbeddedText(char *pszFileName, size_t nMaxHiddenBits);
int  StegoGetNextBit();
void StegoCloseEmbeddedText();

/* Decoding */
void StegoCreateEmbeddedText();
void SaveHiddenBit(int bit);
void StegoFlushEmbeddedText(char *pszFileName);

#endif /* _STEGO_H_ */

