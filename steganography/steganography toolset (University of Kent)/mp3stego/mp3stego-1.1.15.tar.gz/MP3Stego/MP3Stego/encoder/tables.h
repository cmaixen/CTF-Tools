#ifndef TABLES_H
#define TABLES_H

struct scalefac_struct
{
   int l[23];
   int s[14];
};


extern struct scalefac_struct sfBandIndex[6]; 
extern float  absthr_0[];
extern float  absthr_1[];
extern float  absthr_2[];
extern double enwindow[];

#endif

